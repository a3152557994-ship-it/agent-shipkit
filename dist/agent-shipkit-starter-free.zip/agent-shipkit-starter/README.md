# Agent ShipKit — Starter Free Pack (1 of 6 Skills)

Includes `geo-llms-auditor` (SKILL.md + zero-dep `audit-geo.mjs` CLI).

## Install in 1 Command
```bash
node install-skills.mjs --target claude      # or --target cursor / --target antigravity
```

Upgrade to the Full 6-Skill Commercial Bundle ($29 / ¥99): https://a3152557994-ship-it.github.io/agent-shipkit/
